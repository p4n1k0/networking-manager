import request from 'supertest';
import app from '../src/app'; // ou server.js se exportar o app Express

describe('Healthcheck API', () => {
  it('deve retornar status ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});
